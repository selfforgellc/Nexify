"""Command-line interface for nexify (Click-based)."""

from __future__ import annotations

import click

import nexify
from nexify.cli._bootstrap import bootstrap_cmd
from nexify.cli.add_cmd import add
from nexify.cli.agent_cmd import agent
from nexify.cli.ask import ask
from nexify.cli.bench_cmd import bench
from nexify.cli.channel_cmd import channel
from nexify.cli.channels_cmd import channels
from nexify.cli.chat_cmd import chat
from nexify.cli.compose_cmd import compose
from nexify.cli.config_cmd import config
from nexify.cli.connect_cmd import connect
from nexify.cli.daemon_cmd import restart, start, status, stop
from nexify.cli.deep_research_setup_cmd import deep_research_setup
from nexify.cli.digest_cmd import digest
from nexify.cli.doctor_cmd import doctor
from nexify.cli.eval_cmd import eval_group
from nexify.cli.feedback_cmd import feedback_group
from nexify.cli.gateway_cmd import gateway
from nexify.cli.host_cmd import host
from nexify.cli.init_cmd import init
from nexify.cli.memory_cmd import memory
from nexify.cli.mine_cmd import mine
from nexify.cli.model import model
from nexify.cli.operators_cmd import operators
from nexify.cli.optimize_cmd import optimize_group
from nexify.cli.pearl_cmd import pearl
from nexify.cli.quickstart_cmd import quickstart
from nexify.cli.registry_cmd import registry
from nexify.cli.scan_cmd import scan
from nexify.cli.scheduler_cmd import scheduler
from nexify.cli.serve import serve
from nexify.cli.skill_cmd import skill
from nexify.cli.telemetry_cmd import telemetry
from nexify.cli.tool_cmd import tool
from nexify.cli.vault_cmd import vault
from nexify.cli.workflow_cmd import workflow
from nexify.learning.distillation.cli import learning_group


@click.group(
    help="nexify — modular AI assistant backend",
    invoke_without_command=True,
)
@click.version_option(version=nexify.__version__, prog_name="jarvis")
@click.option("--verbose", is_flag=True, default=False, help="Enable debug logging")
@click.option("--quiet", is_flag=True, default=False, help="Suppress non-error output")
@click.pass_context
def cli(ctx: click.Context, verbose: bool, quiet: bool) -> None:
    """Top-level CLI group."""
    from nexify.cli.log_config import setup_logging

    ctx.ensure_object(dict)
    ctx.obj["verbose"] = verbose
    ctx.obj["quiet"] = quiet
    setup_logging(verbose=verbose, quiet=quiet)

    # Check for updates on interactive commands
    if not quiet and ctx.invoked_subcommand:
        from nexify.cli._version_check import check_for_updates

        check_for_updates(ctx.invoked_subcommand)

    # First-run guard — routes bare `jarvis` to chat or init.
    if ctx.invoked_subcommand is None:
        from nexify.cli._first_run import check_and_route

        check_and_route(ctx)


cli.add_command(init, "init")
cli.add_command(ask, "ask")
cli.add_command(chat, "chat")
cli.add_command(serve, "serve")
cli.add_command(model, "model")
cli.add_command(memory, "memory")
cli.add_command(mine, "mine")
cli.add_command(pearl, "pearl")
cli.add_command(telemetry, "telemetry")
cli.add_command(bench, "bench")
cli.add_command(channel, "channel")
cli.add_command(channels, "channels")
cli.add_command(scheduler, "scheduler")
cli.add_command(doctor, "doctor")
cli.add_command(agent, "agents")
cli.add_command(workflow, "workflow")
cli.add_command(skill, "skill")
cli.add_command(start, "start")
cli.add_command(stop, "stop")
cli.add_command(restart, "restart")
cli.add_command(status, "status")
cli.add_command(vault, "vault")
cli.add_command(add, "add")
cli.add_command(operators, "operators")
cli.add_command(eval_group, "eval")
cli.add_command(host, "host")
cli.add_command(quickstart, "quickstart")
cli.add_command(optimize_group, "optimize")
cli.add_command(feedback_group, "feedback")
cli.add_command(compose, "compose")
cli.add_command(gateway, "gateway")
cli.add_command(tool, "tool")
cli.add_command(registry, "registry")
cli.add_command(config, "config")
cli.add_command(scan, "scan")
cli.add_command(connect, "connect")
cli.add_command(digest, "digest")
cli.add_command(deep_research_setup, "deep-research-setup")
cli.add_command(deep_research_setup, "research")
cli.add_command(learning_group, "learning")
cli.add_command(bootstrap_cmd, "_bootstrap")

# Gateway CLI commands (lazy import to avoid pulling starlette)
try:
    from nexify.cli.auth_cmd import auth

    cli.add_command(auth, "auth")
except ImportError:
    pass

try:
    from nexify.cli.tunnel_cmd import tunnel

    cli.add_command(tunnel, "tunnel")
except ImportError:
    pass


def main() -> None:
    """Entry point registered as ``jarvis`` console script."""
    cli()


__all__ = ["cli", "main"]

