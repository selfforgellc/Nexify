"""nexify Evaluation Framework."""

